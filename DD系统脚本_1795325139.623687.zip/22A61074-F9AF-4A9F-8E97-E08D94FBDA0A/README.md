# dd.sh — VPS 一键重装系统脚本

交互式一键 DD（网络重装）脚本：运行后从菜单里选想要的系统与版本，确认后自动完成重装。
底层调用上游成熟的重装组件 [leitbogioro/Tools](https://github.com/leitbogioro/Tools)（InstallNET.sh），
多源下载（GitHub raw / jsDelivr / ghproxy）并自动重试，避免被墙导致失败。

> ⚠️ **重装会清空整块磁盘，数据不可恢复。** 执行前请务必在服务商面板做快照/备份，并确认控制台可用 VNC 连接。

---

## 一、快速开始

把 `dd.sh` 上传到 VPS（或直接复制内容），然后：

```bash
# 1) 给执行权限
chmod +x dd.sh

# 2) 先演练一遍：只打印最终命令，不改动系统（强烈建议）
bash dd.sh --dry-run

# 3) 正式执行，进入交互菜单
bash dd.sh
```

菜单流程：

```
请选择系统编号 -> 设置密码（回车自动生成 16 位强随机密码）
-> SSH 端口 -> 系统语言 -> 网络方式(自动/DHCP/静态IP)
-> 查看参数汇总 -> 输入 YES 确认 -> 自动开始重装
```

## 二、支持的系统

| 分类 | 版本 |
|---|---|
| Debian | 13 / 12 / 11 / 10 |
| Ubuntu | 24.04 / 22.04 / 20.04 LTS |
| AlmaLinux | 9 / 8 |
| Rocky Linux | 9 / 8 |
| CentOS | 7 |
| Oracle Linux | 9 / 8 |
| Alpine / Arch / Kali | 最新版 |
| Windows | Server 2025 / 2022 / 2019、Windows 11 企业版、Windows 10 LTSC |

## 三、命令行参数（可跳过交互）

```bash
bash dd.sh -os 2 -p 'MyPassw0rd' -port 2222              # 按菜单编号选
bash dd.sh -os debian12 -p 'MyPassw0rd'                  # 按名字选
bash dd.sh -os "Ubuntu 24.04" -p 'MyPassw0rd' -lang en
bash dd.sh -os debian12 -net static -ip 1.2.3.4 -mask 255.255.255.0 -gw 1.2.3.1
bash dd.sh -os windows2022 -p 'MyPassw0rd'               # Windows
bash dd.sh -os 2 -y                                     # 跳过最后 YES 确认（慎用）
bash dd.sh -h                                           # 帮助
```

| 参数 | 说明 |
|---|---|
| `-os, --os` | 系统编号或名称（如 `2`、`debian12`、`windows2022`），省略则进菜单 |
| `-p, --password` | 登录密码，省略则在交互中询问（留空自动生成） |
| `-port` | SSH 端口，默认 22（Windows 走 RDP 3389） |
| `-lang` | `cn` / `en`，默认 `cn` |
| `-net` | `dhcp` / `static`，留空表示交互选择 |
| `-ip / -mask / -gw` | 静态 IP 参数，脚本会自动填入当前检测到的值 |
| `-n, --dry-run` | 演练模式：只打印命令不执行 |
| `-y, --yes` | 跳过最后的 `YES` 二次确认 |

## 四、脚本做了哪些事

1. **环境体检**：OS、内核、CPU 架构（x86_64 / aarch64）、虚拟化类型、内存、根分区容量、网卡与网络参数，执行前一次性展示。
2. **参数收集**：系统、密码、端口、语言、网络方式，全部集中在菜单里完成，无需记忆上游参数。
3. **二次确认**：汇总表 + 输入 `YES` 才真正开始，附 `--dry-run` 演练模式。
4. **多源下载**：上游脚本 3 个源、每个源 2 次重试，下载后校验 shebang。
5. **参数留档**：把本次重装的系统、密码、端口、完整命令写到 `/root/dd-<时间戳>.log`，重装后可用于核对（重装本身会清空磁盘，建议先记录下来）。

## 五、常见问题

**Q：重装后连不上怎么办？**
先看服务商控制台 VNC：若是网络配置问题，重新用 `-net dhcp` 或补全静态 IP 参数再跑一次。

**Q：提示下载失败？**
脚本已内置 jsDelivr / ghproxy 镜像。若全失败，通常是 DNS 或出网被限制，可手动下载 `InstallNET.sh` 到本机后用 `bash InstallNET.sh <参数>` 执行（完整参数见脚本汇总输出）。

**Q：OpenVZ / LXC 能用吗？**
网络重装通常只在 KVM / 物理机生效。OpenVZ、LXC 这类共享内核容器不支持，脚本运行前的环境信息里可直接看到虚拟化类型。

**Q：上游参数会不会变？**
`dd.sh` 只是参数拼装器，实际能力来自上游 InstallNET.sh。若上游参数调整，只需改脚本 `build_args()` 里对应的 flag；也可在 `print_summary` 输出的命令基础上手工微调后自行执行。

**Q：内存/磁盘太小？**
Linux 建议 ≥512MB 内存、≥5GB 磁盘；Windows 建议 ≥2GB 内存、≥20GB 磁盘，否则重装后体验极差或失败。

## 六、文件结构

```
dd.sh        # 主脚本（唯一必需文件）
README.md    # 本说明
```

## 七、免责声明

本脚本仅做参数封装与流程编排，磁盘擦写与引导改写由上游组件完成。使用即代表你了解风险并自行承担后果，
请勿在生产环境未经备份直接执行。
