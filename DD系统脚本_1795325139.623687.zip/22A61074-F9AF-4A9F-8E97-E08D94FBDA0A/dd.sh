#!/usr/bin/env bash
#
#  dd.sh — VPS 一键网络重装系统 (Linux / Windows)
#
#  特性:
#    1. 交互式菜单，一键选择想要的系统与版本
#    2. 自动识别 CPU 架构 / 内存 / 磁盘 / 虚拟化
#    3. 自动读取当前 IP / 网关 / 掩码，支持 DHCP 或静态 IP 重装
#    4. 可指定密码、SSH 端口、系统语言；密码留空则自动生成强随机密码
#    5. --dry-run 只打印将要执行的命令，便于先确认再执行
#    6. 多源下载（GitHub raw / jsDelivr / ghproxy）并自动重试
#
#  用法:
#    bash dd.sh                  # 交互式菜单（推荐）
#    bash dd.sh --dry-run        # 演练：只显示最终命令，不做任何修改
#    bash dd.sh -os 2 -p MyPass -port 2222
#    bash dd.sh -os debian12 -p MyPass
#    bash dd.sh -h
#
#  免责声明:
#    重装系统会清空整块磁盘数据，不可恢复。执行前请务必在服务商面板做好快照/备份。
#
set -uo pipefail
export LC_ALL=C

VERSION="1.0.0"

# ---------------------------------------------------------------- 颜色与输出
if [[ -t 1 ]]; then
  RED=$'\033[31m'; GREEN=$'\033[32m'; YELLOW=$'\033[33m'
  CYAN=$'\033[36m'; BOLD=$'\033[1m'; DIM=$'\033[2m'; NC=$'\033[0m'
else
  RED=""; GREEN=""; YELLOW=""; CYAN=""; BOLD=""; DIM=""; NC=""
fi
info() { printf '%s[信息]%s %s\n' "$CYAN" "$NC" "$*"; }
ok()   { printf '%s[完成]%s %s\n' "$GREEN" "$NC" "$*"; }
warn() { printf '%s[警告]%s %s\n' "$YELLOW" "$NC" "$*"; }
err()  { printf '%s[错误]%s %s\n' "$RED" "$NC" "$*" >&2; }
hr()   { printf '%s\n' "============================================================"; }

on_interrupt() {
  printf '\n'
  warn "已取消操作，未对系统做任何修改。"
  exit 130
}
trap on_interrupt INT TERM

# ---------------------------------------------------------------- 全局配置
DRY_RUN=0
OS_ARG=""
PASSWORD=""
SSH_PORT="22"
LANG_OPT="cn"
NET_MODE="auto"        # auto(默认跟随当前环境) | dhcp | static
NET_IP=""; NET_GW=""; NET_MASK=""

LEIT_URLS=(
  "https://raw.githubusercontent.com/leitbogioro/Tools/master/Linux_reinstall/InstallNET.sh"
  "https://cdn.jsdelivr.net/gh/leitbogioro/Tools@master/Linux_reinstall/InstallNET.sh"
  "https://ghproxy.net/https://raw.githubusercontent.com/leitbogioro/Tools/master/Linux_reinstall/InstallNET.sh"
)
MOECLUB_URLS=(
  "https://raw.githubusercontent.com/MoeClub/Note/master/InstallNET.sh"
  "https://cdn.jsdelivr.net/gh/MoeClub/Note@master/InstallNET.sh"
)
WORK_DIR="/tmp/dd-$$"

# ---------------------------------------------------------------- 系统清单
# 格式: "显示名称|上游参数|-|类型"
OS_ENTRIES=(
  "Debian 12 (Bookworm)        |debian|12|linux"
  "Debian 11 (Bullseye)        |debian|11|linux"
  "Debian 13 (Trixie)          |debian|13|linux"
  "Debian 10 (Buster)          |debian|10|linux"
  "Ubuntu 24.04 LTS            |ubuntu|24.04|linux"
  "Ubuntu 22.04 LTS            |ubuntu|22.04|linux"
  "Ubuntu 20.04 LTS            |ubuntu|20.04|linux"
  "AlmaLinux 9                 |alma|9|linux"
  "AlmaLinux 8                 |alma|8|linux"
  "Rocky Linux 9               |rocky|9|linux"
  "Rocky Linux 8               |rocky|8|linux"
  "CentOS 7                    |centos|7|linux"
  "Oracle Linux 9              |oracle|9|linux"
  "Oracle Linux 8              |oracle|8|linux"
  "Alpine Linux (最新)         |alpine||linux"
  "Arch Linux (最新)           |arch||linux"
  "Kali Linux (最新)           |kali||linux"
  "Windows Server 2022         |windows|2022|windows"
  "Windows Server 2019         |windows|2019|windows"
  "Windows Server 2025         |windows|2025|windows"
  "Windows 11 企业版           |windows|11|windows"
  "Windows 10 LTSC             |windows|10|windows"
)

# ---------------------------------------------------------------- 基础工具
have() { command -v "$1" >/dev/null 2>&1; }

need_root() {
  if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    err "必须以 root 身份运行。请执行: sudo bash dd.sh"
    exit 1
  fi
}

ensure_tools() {
  if ! have curl && ! have wget; then
    warn "未检测到 curl/wget，尝试安装 curl ..."
    if have apt-get; then apt-get update -qq && apt-get install -y -qq curl
    elif have yum; then yum install -y -q curl
    elif have apk; then apk add --no-cache curl
    fi
  fi
  if ! have curl && ! have wget; then
    err "缺少 curl 与 wget，无法下载重装脚本，请先安装其一。"
    exit 1
  fi
}

cleanup() { [[ -d "$WORK_DIR" ]] && rm -rf "$WORK_DIR"; }
trap 'cleanup; on_interrupt' INT TERM

# ---------------------------------------------------------------- 环境探测
detect_arch() {
  case "$(uname -m)" in
    x86_64|amd64)  ARCH_SHORT="64";    ARCH_FULL="x86_64" ;;
    aarch64|arm64) ARCH_SHORT="arm64"; ARCH_FULL="aarch64" ;;
    *)             ARCH_SHORT="64";    ARCH_FULL="$(uname -m)" ;;
  esac
}

detect_virt() {
  VIRT="未知"
  if have systemd-detect-virt; then
    VIRT="$(systemd-detect-virt 2>/dev/null || true)"
    [[ -z "$VIRT" || "$VIRT" == "none" ]] && VIRT="物理机/裸金属"
  elif [[ -d /proc/vz && ! -d /proc/bc ]]; then VIRT="OpenVZ"
  elif [[ -f /.dockerenv ]]; then VIRT="Docker 容器"
  elif have dmidecode && dmidecode -s system-product-name 2>/dev/null | grep -qi kvm; then VIRT="KVM"
  fi
}

detect_current_os() {
  if [[ -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    CUR_OS="${PRETTY_NAME:-${NAME:-未知} ${VERSION_ID:-}}"
  else
    CUR_OS="$(uname -s) $(uname -r)"
  fi
  CUR_KERNEL="$(uname -r)"
  MEM_MB=$(awk '/MemTotal/{printf "%d", $2/1024}' /proc/meminfo 2>/dev/null || echo 0)
  DISK_INFO=$(df -h / 2>/dev/null | awk 'NR==2{print $2" (已用 "$5")"}' || echo "未知")
}

detect_network() {
  NET_DEV="$(ip route show default 2>/dev/null | awk '/^default/{print $5; exit}')"
  [[ -z "${NET_DEV:-}" ]] && NET_DEV="$(ls /sys/class/net | grep -v lo | head -n1)"
  NET_GW="$(ip route show default 2>/dev/null | awk '/^default/{print $3; exit}')"
  local cidr
  cidr="$(ip -4 -o addr show scope global dev "${NET_DEV:-eth0}" 2>/dev/null | awk '{print $4; exit}')"
  if [[ -z "$cidr" ]]; then
    cidr="$(ip -4 -o addr show scope global 2>/dev/null | awk '{print $4; exit}')"
  fi
  NET_IP="${cidr%%/*}"
  NET_PREFIX="${cidr##*/}"
  [[ -z "${NET_IP:-}" ]] && NET_IP="未获取到"
  [[ -z "${NET_PREFIX:-}" || ! "$NET_PREFIX" =~ ^[0-9]+$ ]] && NET_PREFIX="24"
  NET_MASK="$(prefix_to_mask "$NET_PREFIX")"
}

prefix_to_mask() {
  local p="$1" mask="" i octet
  for i in 1 2 3 4; do
    if (( p >= 8 )); then octet=255; p=$((p-8))
    elif (( p <= 0 )); then octet=0
    else octet=$(( 256 - (1 << (8-p)) )); p=0
    fi
    mask+="${octet}"
    (( i < 4 )) && mask+="."
  done
  printf '%s' "$mask"
}

show_env() {
  hr
  printf '%s  当前环境%s\n' "$BOLD" "$NC"
  hr
  printf '  %-14s %s\n' "操作系统" "${CUR_OS:-未知}"
  printf '  %-14s %s\n' "内核版本" "${CUR_KERNEL:-未知}"
  printf '  %-14s %s (%s)\n' "CPU 架构" "${ARCH_FULL:-未知}" "${ARCH_SHORT:-}"
  printf '  %-14s %s\n' "虚拟化" "${VIRT:-未知}"
  printf '  %-14s %s MB\n' "内存" "${MEM_MB:-0}"
  printf '  %-14s %s\n' "根分区" "${DISK_INFO:-未知}"
  printf '  %-14s %s\n' "网卡" "${NET_DEV:-未知}"
  printf '  %-14s %s\n' "IP / 掩码" "${NET_IP:-未知} / ${NET_MASK:-未知}"
  printf '  %-14s %s\n' "网关" "${NET_GW:-未知}"
  hr
}

# ---------------------------------------------------------------- 交互工具
rand_pass() { tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 16; }

ask() {          # ask "提示" "默认值" -> 输出结果
  local prompt="$1" def="${2:-}" ans=""
  if [[ -n "$def" ]]; then
    printf '%s [%s]: ' "$prompt" "$def" >&2
  else
    printf '%s: ' "$prompt" >&2
  fi
  if ! read -r ans; then ans=""; fi
  printf '%s' "${ans:-$def}"
}

ask_yes_no() {   # ask_yes_no "提示" 默认(y/n) -> 0=yes
  local prompt="$1" def="${2:-n}" ans
  ans="$(ask "$prompt (y/n)" "$def")"
  [[ "$ans" =~ ^[Yy]([Ee][Ss])?$ ]]
}

resolve_os_arg() {
  # 允许 -os 2 / -os debian12 / -os "Debian 12"
  local raw="$1" key lower idx=0 entry
  lower="$(printf '%s' "$raw" | tr 'A-Z' 'a-z' | tr -d ' -_')"
  if [[ "$lower" =~ ^[0-9]+$ ]] && (( lower >= 1 && lower <= ${#OS_ENTRIES[@]} )); then
    printf '%s' "$lower"; return 0
  fi
  for entry in "${OS_ENTRIES[@]}"; do
    idx=$((idx+1))
    local flag ver name
    flag="$(cut -d'|' -f2 <<<"$entry")"
    ver="$(cut -d'|' -f3 <<<"$entry")"
    name="$(cut -d'|' -f1 <<<"$entry" | tr -d ' ')"
    if [[ "$lower" == "${flag}${ver}" || "$lower" == "${name,,}" && -n "$name" ]]; then
      printf '%s' "$idx"; return 0
    fi
  done
  return 1
}

list_os() {
  hr
  printf '%s  请选择要安装的系统%s\n' "$BOLD" "$NC"
  hr
  local i=0 entry name
  for entry in "${OS_ENTRIES[@]}"; do
    i=$((i+1))
    name="$(cut -d'|' -f1 <<<"$entry" | sed 's/[[:space:]]*$//')"
    printf '  %s%2d%s) %s\n' "$BOLD" "$i" "$NC" "$name"
    # 分组分隔线
    case "$i" in
      4|7|14|17) printf '%s  ----%s\n' "$DIM" "$NC" ;;
    esac
  done
  hr
  printf '  %s0%s) 退出\n' "$BOLD" "$NC"
  hr
}

# ---------------------------------------------------------------- 参数收集
collect_password() {
  local input
  echo
  info "设置${SEL_TYPE_TEXT}登录密码（直接回车 = 自动生成 16 位强随机密码）"
  input="$(ask "密码" "")"
  if [[ -z "$input" ]]; then
    PASSWORD="$(rand_pass)"
    ok "已生成随机密码: ${BOLD}${PASSWORD}${NC}"
  else
    PASSWORD="$input"
  fi
}

collect_port() {
  local input
  echo
  input="$(ask "SSH 端口 (1-65535)" "$SSH_PORT")"
  if [[ "$input" =~ ^[0-9]+$ ]] && (( input >= 1 && input <= 65535 )); then
    SSH_PORT="$input"
  else
    warn "端口非法，已回退为 22。"
    SSH_PORT="22"
  fi
}

collect_lang() {
  local input
  echo
  info "系统语言: 1) 中文  2) 英文"
  input="$(ask "请选择" "1")"
  case "$input" in
    2|en|EN|英文) LANG_OPT="en" ;;
    *)            LANG_OPT="cn" ;;
  esac
}

collect_network() {
  echo
  info "网络配置方式:"
  printf '   1) 自动/DHCP（跟随当前环境，多数场景可用，默认）\n'
  printf '   2) 静态 IP（自动填入当前检测到的 IP/网关/掩码，可修改）\n'
  local input
  input="$(ask "请选择" "1")"
  case "$input" in
    2)
      NET_MODE="static"
      NET_IP="$(ask "IP 地址" "${NET_IP}")"
      NET_MASK="$(ask "子网掩码" "${NET_MASK}")"
      NET_GW="$(ask "网关" "${NET_GW}")"
      ;;
    *)
      NET_MODE="dhcp"
      ;;
  esac
}

# ---------------------------------------------------------------- 下载引擎
fetch_script() {  # fetch_script out_file url...
  local out="$1"; shift
  local url attempt
  for url in "$@"; do
    for attempt in 1 2; do
      info "下载: ${url}"
      if have curl; then
        if curl -fsSL --connect-timeout 15 --max-time 120 -o "$out" "$url" 2>/dev/null \
             && [[ -s "$out" ]] && head -n1 "$out" | grep -q '#!'; then
          return 0
        fi
      else
        if wget -q --timeout=20 --tries=1 -O "$out" "$url" 2>/dev/null \
             && [[ -s "$out" ]] && head -n1 "$out" | grep -q '#!'; then
          return 0
        fi
      fi
      sleep 1
    done
  done
  return 1
}

# ---------------------------------------------------------------- 命令拼装
build_args() {
  ARGS=()
  if [[ "$SEL_FLAG" == "windows" ]]; then
    ARGS+=("-windows" "$SEL_VER")
    ARGS+=("--lang" "$LANG_OPT")
    ARGS+=("-pwd" "$PASSWORD")
  else
    ARGS+=("-${SEL_FLAG}")
    [[ -n "$SEL_VER" ]] && ARGS+=("$SEL_VER")
    ARGS+=("-v" "$ARCH_SHORT")
    ARGS+=("-pwd" "$PASSWORD")
    ARGS+=("-port" "$SSH_PORT")
    ARGS+=("--lang" "$LANG_OPT")
  fi

  case "$NET_MODE" in
    static)
      ARGS+=("--network" "static")
      ARGS+=("--ip-addr" "$NET_IP")
      ARGS+=("--ip-gate" "$NET_GW")
      ARGS+=("--ip-mask" "$NET_MASK")
      ;;
    dhcp)
      ARGS+=("--network" "dhcp")
      ;;
  esac
}

print_summary() {
  hr
  printf '%s  即将执行的操作%s\n' "$BOLD" "$NC"
  hr
  printf '  %-14s %s\n' "目标系统" "$SEL_NAME"
  printf '  %-14s %s\n' "架构" "$ARCH_FULL"
  printf '  %-14s %s\n' "系统语言" "$([[ "$LANG_OPT" == cn ]] && echo 中文 || echo 英文)"
  printf '  %-14s %s\n' "密码" "$PASSWORD"
  if [[ "$SEL_FLAG" == "windows" ]]; then
    printf '  %-14s %s\n' "远程端口" "3389 (RDP)"
  else
    printf '  %-14s %s\n' "SSH 端口" "$SSH_PORT"
  fi
  if [[ "$NET_MODE" == "static" ]]; then
    printf '  %-14s %s / %s / %s\n' "静态网络" "$NET_IP" "$NET_MASK" "$NET_GW"
  elif [[ "$NET_MODE" == "dhcp" ]]; then
    printf '  %-14s %s\n' "网络" "DHCP"
  else
    printf '  %-14s %s\n' "网络" "自动（跟随当前环境）"
  fi
  hr
  printf '  %s最终命令:%s\n' "$DIM" "$NC"
  printf '  %s\n' "bash InstallNET.sh ${ARGS[*]}"
  hr
}

# ---------------------------------------------------------------- 主流程
parse_cli_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --dry-run|-n) DRY_RUN=1; shift ;;
      -os|--os)     OS_ARG="${2:-}"; shift 2 ;;
      -p|-pwd|--password) PASSWORD="${2:-}"; shift 2 ;;
      -port|--port) SSH_PORT="${2:-}"; shift 2 ;;
      -lang|--lang) LANG_OPT="${2:-}"; shift 2 ;;
      -net|--network) NET_MODE="${2:-}"; shift 2 ;;
      -ip|--ip)     NET_IP="${2:-}"; shift 2 ;;
      -gw|--gateway) NET_GW="${2:-}"; shift 2 ;;
      -mask|--mask) NET_MASK="${2:-}"; shift 2 ;;
      -y|--yes)     ASSUME_YES=1; shift ;;
      -h|--help)
        sed -n '2,30p' "$0" | sed 's/^#\s\?//'
        exit 0 ;;
      *) err "未知参数: $1（使用 -h 查看帮助）"; exit 1 ;;
    esac
  done
}

main() {
  ASSUME_YES=0
  parse_cli_args "$@"
  need_root
  ensure_tools
  mkdir -p "$WORK_DIR"

  detect_arch; detect_virt; detect_current_os; detect_network

  hr
  printf '%s  VPS 一键重装系统脚本 · dd.sh v%s%s\n' "$BOLD" "$VERSION" "$NC"
  hr
  warn "重装会清空整块磁盘，数据不可恢复。请先在服务商面板备份/快照！"
  warn "请确认服务商控制台可 VNC 连接，以免重装后失联无法救援。"

  if [[ "$DRY_RUN" -eq 1 ]]; then
    warn "当前为演练模式 (--dry-run)，只会打印命令，不会执行重装。"
  fi
  echo

  show_env

  local idx=""
  if [[ -n "$OS_ARG" ]]; then
    idx="$(resolve_os_arg "$OS_ARG")" || {
      err "无法识别的系统参数: $OS_ARG（可用编号或 debian12 之类）"
      list_os
      exit 1
    }
  fi

  while [[ -z "$idx" ]]; do
    list_os
    local choice
    choice="$(ask "输入编号" "")"
    if [[ "$choice" == "0" ]]; then info "已退出。"; exit 0; fi
    if [[ "$choice" =~ ^[0-9]+$ ]] && (( choice >= 1 && choice <= ${#OS_ENTRIES[@]} )); then
      idx="$choice"
    else
      warn "输入无效，请重新选择。"
    fi
  done

  local entry="${OS_ENTRIES[$((idx-1))]}"
  SEL_NAME="$(cut -d'|' -f1 <<<"$entry" | sed 's/[[:space:]]*$//')"
  SEL_FLAG="$(cut -d'|' -f2 <<<"$entry")"
  SEL_VER="$(cut -d'|' -f3 <<<"$entry")"
  SEL_TYPE="$(cut -d'|' -f4 <<<"$entry")"

  if [[ "$SEL_TYPE" == "windows" ]]; then
    SEL_TYPE_TEXT="Windows 管理员"
  else
    SEL_TYPE_TEXT=" root "
  fi

  [[ -z "$PASSWORD" ]] && collect_password
  if [[ "$SEL_FLAG" != "windows" ]]; then
    collect_port
  fi
  collect_lang

  if [[ "$NET_MODE" == "auto" ]]; then
    collect_network
  elif [[ "$NET_MODE" == "static" ]]; then
    [[ -z "$NET_IP" ]]   && NET_IP="$(ask "IP 地址" "${NET_IP}")"
    [[ -z "$NET_GW" ]]   && NET_GW="$(ask "网关" "${NET_GW}")"
    [[ -z "$NET_MASK" ]] && NET_MASK="$(ask "子网掩码" "${NET_MASK}")"
  fi

  build_args
  print_summary

  if [[ "$DRY_RUN" -eq 1 ]]; then
    ok "演练结束，未执行任何操作。去掉 --dry-run 即可真正重装。"
    exit 0
  fi

  if [[ "$ASSUME_YES" -ne 1 ]]; then
    echo
    warn "最后确认：输入 ${BOLD}YES${NC} 开始重装（其它任意输入将取消）"
    local confirm
    confirm="$(ask "请输入" "")"
    if [[ "$confirm" != "YES" ]]; then
      info "已取消，系统未做任何修改。"
      exit 0
    fi
  fi

  local script="$WORK_DIR/InstallNET.sh"
  info "正在获取上游重装组件 ..."
  if ! fetch_script "$script" "${LEIT_URLS[@]}"; then
    err "上游脚本下载失败（网络受限或 GitHub 被墙）。"
    info "可尝试手动下载后执行:"
    printf '    %s\n' "${LEIT_URLS[0]}"
    exit 1
  fi
  chmod +x "$script"
  ok "组件就绪: $script"

  # 保存记录，便于重装后核对
  local record="/root/dd-$(date +%Y%m%d-%H%M%S).log"
  {
    echo "时间: $(date '+%F %T')"
    echo "目标: $SEL_NAME  ($SEL_FLAG $SEL_VER)  架构: $ARCH_FULL"
    echo "密码: $PASSWORD"
    [[ "$SEL_FLAG" != "windows" ]] && echo "SSH 端口: $SSH_PORT"
    echo "命令: bash InstallNET.sh ${ARGS[*]}"
  } > "$record" 2>/dev/null || true
  info "参数已记录到: $record"

  echo
  warn "开始执行，系统将在数分钟内重启并重装，请勿中断！"
  sleep 3
  cd "$WORK_DIR" || exit 1

  # 直接在该 shell 中执行上游脚本，保证其后续逻辑（下载镜像、写引导）正常接管
  exec bash "$script" "${ARGS[@]}"
}

main "$@"
